import {
  BACKEND_NOT_CONFIGURED_MESSAGE,
  SCAN_FUNCTION_URL,
  SUPABASE_ANON_KEY,
  supabase,
} from '@/lib/supabase';
import type { ScanResult, ScanRow } from '@/types/scan';

interface ScanResponse {
  id: string;
  result: ScanResult;
}

function requireBackend() {
  if (!supabase || !SCAN_FUNCTION_URL) throw new Error(BACKEND_NOT_CONFIGURED_MESSAGE);
  return { client: supabase, scanUrl: SCAN_FUNCTION_URL };
}

export async function runSecurityScan(domain: string): Promise<ScanResponse> {
  const { scanUrl } = requireBackend();
  let response: Response;
  try {
    response = await fetch(scanUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ domain, authorized: true }),
    });
  } catch {
    throw new Error('Could not reach the scanning service. Check your connection and try again.');
  }

  const body = (await response.json().catch(() => null)) as Partial<ScanResponse> & { error?: string } | null;
  if (!response.ok) {
    throw new Error(body?.error ?? `The scan failed (HTTP ${response.status}).`);
  }
  if (!body || typeof body.id !== 'string' || !body.result) {
    throw new Error('The scanning service returned an unexpected response.');
  }
  return { id: body.id, result: body.result };
}

export async function fetchScan(id: string): Promise<ScanRow | null> {
  const { client } = requireBackend();
  const { data, error } = await client.from('scans').select('*').eq('id', id).maybeSingle();
  if (error) throw new Error('Could not load this scan.');
  return (data as ScanRow | null) ?? null;
}

export async function fetchRecentScans(limit = 50): Promise<ScanRow[]> {
  const { client } = requireBackend();
  const { data, error } = await client
    .from('scans')
    .select('id, domain, status, risk_score, risk_category, result, duration_ms, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw new Error('Could not load scan history.');
  return (data ?? []) as ScanRow[];
}
