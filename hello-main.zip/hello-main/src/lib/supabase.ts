import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isBackendConfigured = Boolean(url && anonKey);
export const BACKEND_NOT_CONFIGURED_MESSAGE =
  'The scan backend is not connected to this preview yet, so scans and saved results are unavailable.';

export const supabase: SupabaseClient | null = url && anonKey ? createClient(url, anonKey) : null;
export const SCAN_FUNCTION_URL: string | null = url ? `${url}/functions/v1/scan-domain` : null;
export const THREAT_FUNCTION_URL: string | null = url ? `${url}/functions/v1/threat-intel` : null;
export const SUPABASE_ANON_KEY: string = anonKey ?? '';
